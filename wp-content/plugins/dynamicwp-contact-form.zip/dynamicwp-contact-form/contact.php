<?php

/*
Plugin Name: DynamicWP Contact Form
Plugin URI: http://www.dynamicwp.net/plugins/free-plugin-dynamicwp-contact-form/
Description: Contact form, hidden in the left of your page. If  contact form button clicked, the contact form appears with sliding effect.
Author: Reza Erauansyah
Version: 1.0
Author URI: http://www.dynamicwp.net
*/

if (!class_exists("DynamicwpContactForm")) {
	class DynamicwpContactForm {
		var $adminOptionsName = "DynamicwpContactFormAdminOptions";
		function DynamicwpContactForm() { //constructor
			
		}
		function init() {
			$this->getAdminOptions();
		}
		//Returns an array of admin options
		function getAdminOptions() {
			$contactAdminOptions = array(
				'emailaddress' => '',
				'facebook' => '',
				'twitter' => '',
				'linkedin' => '',
				'stumbleupon' => '',
				'tumbler' => '',
				'delicious' => '',
				'flickr' => ''
				);
			$contactOptions = get_option($this->adminOptionsName);
			if (!empty($contactOptions)) {
				foreach ($contactOptions as $key => $option)
					$contactAdminOptions[$key] = $option;
			}				
			update_option($this->adminOptionsName, $contactAdminOptions);
			return $contactAdminOptions;
		}
		
		//Add jquery
		function mycontactpunc(){
			   wp_deregister_script('jquery');
			   wp_register_script('jquery', ("http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"), false, '');
	 		  wp_enqueue_script('jquery');
		}
			
		function mycontactstyle(){?>
			<style type="text/css">
				.dwp-contact-wrapper { 
					display: block;
					width: 380px;
					position: fixed;
					right: -344px;
					top: 32%;
					z-index: 100;}
				#dwp-contact-button {top:110px;  width: 43px; outline: none; }
				.dwpcontact-page{ position: fixed; top: 100px; left: 0; padding: 10px 20px 5px 20px; background: #fff; -moz-border-radius: 5px; -khtml-border-radius: 5px; -webkit-border-radius: 5px; border-radius: 5px; width: 314px; color: #000; }
				.contact-content {padding-left: 50px; padding: 10px;}
				.dwpcontact-page{top:-55px; border-radius:5px 5px 5px 5px}
				.dwp-contact-button-wrap{margin-top: 10px; margin-bottom: 10px;}
				.dwp-contact-button-wrap img{float: right; margin-left: 10px; background: none repeat scroll 0 0 #FFFFFF;}
				.contact-button h2 {-webkit-transform: rotate(-90deg);
					background: url("images/contact-image.png");
					background: #e95b0c;
					height: 41px;
					width: 105px;
					padding: 25px;
					color:#fff;
					font-family: helvetica, arial, sans-serif;
				}
				.contact-button{ transform: rotate(-90deg); }
				.contact-button {position: fixed;margin: 40px 0px 0px -25px;width: 95px;}
				.contact-info {padding:10px 0px 10px 50px;}

			</style>	
			
		<?php	}

		//Add contact script
		function mycontactscript(){
			$contactOptions = $this->getAdminOptions();

			$emailaddress = $contactOptions['emailaddress'];
			$facebook = $contactOptions['facebook'];
			$twitter = $contactOptions['twitter'];
			$linkedin = $contactOptions['linkedin'];
			$stumbleupon = $contactOptions['stumbleupon'];
			$tumbler = $contactOptions['tumbler'];
			$flickr = $contactOptions['flickr'];
			$delicious = $contactOptions['delicious'];
 
			$linkss = WP_PLUGIN_URL.'/'.str_replace(basename( __FILE__),"",plugin_basename(__FILE__));
			echo "<script type=\"text/javascript\" charset=\"utf-8\" src=\"".$linkss."jquery.form.js\"></script>";

			echo "
			<script type=\"text/javascript\">

				var echa = jQuery.noConflict();
				echa(document).ready(function() {
					echa(\"#dwp-contact-button\").click(function() {
						echa(\".dwpcontact-page\").animate({ left: parseInt(echa(\".dwpcontact-page\").css(\"left\"),0) == 0 ? -354 :  0 });
						echa(\"#dwp-contact-button\").animate({ left: parseInt(echa(\"#dwp-contact-button\").css(\"left\"),0) == 0 ? 354 :  0 });
						return false;
					});
				});

				
			</script> ";?>
<div class="dwp-contact-wrapper" style="float: left;">	
			<div class="dwpcontact-page" style="position: relative; float: right; text-align: right; width: 100%; padding-right:10px;">				
				<div class="contact-content">
					<div id="dwp-contact-button" class="contact-button"><h2>Contact</h2></div>
					<div class="contact-info">
						<label class="contact-label" for="name">Contact Freelance </label>
						<label class="contact-label" for="email">Phone: 1800 628 014</label>						
						<label class="contact-label" for="subject">Fax: 03 9428  1674 </label>												
						<label class="contact-label" for="comment">Email: info@freelance.com </label>											
						<a href="#" class="contact_button">General Inquiry</a>
						<a href="#" class="contact_button">Contractor Inquiry</a>
						<a href="#" class="contact_button">Business Inquiry</a>
						</div>
				</div>
			</div>
			
</div>
		<?php
		}	

		//Prints out the admin page
		function printAdminPage() {
					$contactOptions = $this->getAdminOptions();
										
					if (isset($_POST['update_DynamicwpContactFormSettings'])) { 
						if (isset($_POST['emailaddress'])) {
							$contactOptions['emailaddress'] = $_POST['emailaddress'];
						}
						if (isset($_POST['facebook'])) {
							$contactOptions['facebook'] = $_POST['facebook'];
						}
						if (isset($_POST['twitter'])) {
							$contactOptions['twitter'] = $_POST['twitter'];
						}
						if (isset($_POST['linkedin'])) {
							$contactOptions['linkedin'] = $_POST['linkedin'];
						}
						if (isset($_POST['stumbleupon'])) {
							$contactOptions['stumbleupon'] = $_POST['stumbleupon'];
						}
						if (isset($_POST['tumbler'])) {
							$contactOptions['tumbler'] = $_POST['tumbler'];
						}
						if (isset($_POST['tumbler'])) {
							$contactOptions['tumbler'] = $_POST['tumbler'];
						}
						if (isset($_POST['flickr'])) {
							$contactOptions['flickr'] = $_POST['flickr'];
						}
						if (isset($_POST['delicious'])) {
							$contactOptions['delicious'] = $_POST['delicious'];
						}
						
						update_option($this->adminOptionsName, $contactOptions);
						
						?>
						
						<div class="updated"><p><strong><?php _e("Settings Updated.", "DynamicwpContactForm");?></strong></p></div>
						
						<?php } ?>
						<div class="wrap">
							<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
							<h2><a href="http://www.dynamicwp.net">DynamicWP</a> Contact Form</h2>
							
							<div style="width: 50%; ">
								<h2>Email Address</h2>
								<b><label for="dwpemailaddress">email address : </label></b><br />
								<input type="text" id="dwpemailaddress" name="emailaddress" value="<?php echo $contactOptions['emailaddress'];?>" style="width: 50%; " /><br />
								<small>enter email address, where you received massage from contact form</small>

								<br />
								<hr />
								<br />
								<h2>Social Button</h2>
								<b><label for="dwptwitter">twitter link : </label></b><br />
								<input type="text" id="dwptwitter" name="twitter" value="<?php echo $contactOptions['twitter'];?>" style="width: 50%; " /><br />
								<small>Enter link to your twitter account account  here (use full link, with http://) </small>
				
								<br />

								<b><label for="dwpfacebook">facebook: </label></b><br />
								<input type="text" id="dwpfacebook" name="facebook" value="<?php echo $contactOptions['facebook'];?>" style="width: 50%; " /><br />
								<small>Enter link to your facebook account(use full link, with http://)</small>
								<br />
								<b><label for="dwplinkedin">linkedin : </label></b><br />
								<input type="text" name="linkedin" id="dwplinkedin" value="<?php echo $contactOptions['linkedin'];?>" style="width: 50%;" /><br />
								<small>Enter link to your linkedin account. </small>

								<br />

								<b><label for="dwpstumbleupon">StumbleUpon: </label></b><br />
								<input type="text" id="dwpstumbleupon" name="stumbleupon" value="<?php echo $contactOptions['stumbleupon'];?>" style="width: 50%;" /><br />
								<small>Enter link to your stumbleupon account</small>

								<br />
								<b><label for="dwptumbler">Tumbler : </label></b><br />
								<input type="text" id="dwptumbler" name="tumbler" value="<?php echo $contactOptions['tumbler'];?>" style="width: 50%;" /><br />
								<small>Enter link to your tumbler account</small>
								<br />

								<br />
								<b><label for="dwpflickr">Flickr : </label></b><br />
								<input type="text" id="dwpflickr" name="flickr" value="<?php echo $contactOptions['flickr'];?>" style="width: 50%;" /><br />
								<small>Enter link to your Flickr account</small>
								<br />

								<br />
								<b><label for="dwpdelicious">Delicious : </label></b><br />
								<input type="text" id="dwpdelicious" name="delicious" value="<?php echo $contactOptions['delicious'];?>" style="width: 50%;" /><br />
								<small>Enter link to your delicious account</small>
								<br />

							</div>

							<div style="clear:both;"></div>
							
							<div class="submit">
								<input type="submit" name="update_DynamicwpContactFormSettings" value="<?php _e('Update Settings', 'DynamicwpContactForm') ?>" />	
							</div>
							</form>
						</div>
					<?php
				}//End function printAdminPage()
	
	}

} //End Class DynamicwpContactForm

if (class_exists("DynamicwpContactForm")) {
	$contact_plugin = new DynamicwpContactForm();
}

//Initialize the admin panel
if (!function_exists("DynamicwpContactForm_ap")) {
	function DynamicwpContactForm_ap() {
		global $contact_plugin;
		if (!isset($contact_plugin)) {
			return;
		}
		if (function_exists('add_options_page')) {
	add_options_page('<b style="color: #C50606;">DynamicWP Contact Form</b>', '<b style="color: #C50606;">DynamicWP Contact Form</b>', 9, basename(__FILE__), array(&$contact_plugin, 'printAdminPage'));
		}
	}	
}

//Actions and Filters	
if (isset($contact_plugin)) {
	//Actions
	add_action('admin_menu', 'DynamicwpContactForm_ap');
	add_action('activate_contact/contact.php',  array(&$contact_plugin, 'init'));
	
	if(!is_admin()){
	add_action('init', array(&$contact_plugin, 'mycontactpunc')); 
	add_action('wp_footer', array(&$contact_plugin, 'mycontactscript'));
	add_action('wp_head', array(&$contact_plugin, 'mycontactstyle'));
	}
}


?>
