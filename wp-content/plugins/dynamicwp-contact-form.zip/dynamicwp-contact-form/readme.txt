=== DynamicWP Contact Form ===
Contributors: dynamicwp team
Donate link: http://dynamicwp.net
Tags: contact, floating, slide, ajax
Requires at least: 2.8
Tested up to: 3.0
Stable tag: 1.0

An AJAX contact form plugin with the button “contact” that will floating on the left of the web page.

== Description ==

DynamicWP contact form is a free wordpress plugin, a contact form plugin with the button “contact” that will floating on the left of the web page. If the button click, the form will appear with slide effect. The form is using AJAX, so the page wont be reloaded if the massage is succes or failed to deliver.

**Features**

* Easy to install
* AJAX contact form
* Social link button integrated
* Beautiful design

**Demo**

Please check [the plugin demo page](http://www.dynamicwp.net/contact-form-demo-page/).

**Credit** 

This plugin based [The jQuery form Plugin](http://malsup.com/jquery/form)

== Installation ==

1. Decompress the .zip archive and put the “DynamicWP-Contact-Form” category into your plugins directory (/wp-content/plugins/).
1. Or the other way, with your wordpress admin page > Plugins > Add New then choose upload on the top. Next choose File (.zip) then Install Now. (see the screenshots)
1. Activate the plugin in the WordPress Plugins admin page.
1. Go to the DynamicWP Contact Form setting page on Settings > DynamicWP Contact Form then Fill the forms with yours (see the screenshots)

== Screenshots ==

1. DynamicWP Contact Form in Action
2. Plugin installation with Wordpress admin panel
3. The plugin settings page

== Changelog ==

= 1.0 =
* Initial release
